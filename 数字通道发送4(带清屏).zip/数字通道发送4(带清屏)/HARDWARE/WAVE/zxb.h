#ifndef _zxb_H
#define _zxb_H

#include "stm32f4xx.h"


void Set_Sine12bit(float MAX,float MIN);
void  Set_Period(u32 value);
void TIM2_Int_Init(u32 Hz);
void DMA_Transformation_Change(char flag);
void DAC_DMA_Config(void);


#endif

