#ifndef _TIMER_H
#define _TIMER_H

#include "sys.h"

extern void (*Tim4_CallBack)(void);

void TIM4_Init(u16 per,u16 psc);

#endif
