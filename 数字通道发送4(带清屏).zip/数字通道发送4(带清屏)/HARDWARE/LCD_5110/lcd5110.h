#ifndef __LCD5110_H
#define	__LCD5110_H
#include "sys.h"
#include "delay.h"

#define sce0   GPIO_ResetBits(GPIOA, GPIO_Pin_6)  //Ƭѡ
#define res0   GPIO_ResetBits(GPIOA, GPIO_Pin_7)  //��λ,0��λ
#define dc0    GPIO_ResetBits(GPIOA, GPIO_Pin_5)   //1д���ݣ�0дָ��
#define sdin0  GPIO_ResetBits(GPIOA, GPIO_Pin_3)   //����
#define sclk0  GPIO_ResetBits(GPIOA, GPIO_Pin_2)   //ʱ��
#define backled0  GPIO_ResetBits(GPIOA, GPIO_Pin_1)   //����

#define sce1   GPIO_SetBits(GPIOA, GPIO_Pin_6)  //Ƭѡ
#define res1   GPIO_SetBits(GPIOA, GPIO_Pin_7)  //��λ,0��λ
#define dc1    GPIO_SetBits(GPIOA, GPIO_Pin_5)   //1д���ݣ�0дָ��
#define sdin1  GPIO_SetBits(GPIOA, GPIO_Pin_3)   //����
#define sclk1  GPIO_SetBits(GPIOA, GPIO_Pin_2)   //ʱ��
#define backled1  GPIO_SetBits(GPIOA, GPIO_Pin_1)   //����

void LCD_init(void);
void LCD_write_byte(unsigned char dt, unsigned char command);
void LCD_set_XY(unsigned char X, unsigned char Y);
void LCD_clear(void);
void LCD_write_char(unsigned char c);
void LCD_write_String(unsigned char X,unsigned char Y,char *s);
void LCD_write_shu(unsigned char row, unsigned char page,unsigned char c); //row:�� page:ҳ dd:�ַ�
void LCD_write_hanzi(unsigned char row, unsigned char page,unsigned char c); //row:�� page:ҳ dd:�ַ�

#endif
