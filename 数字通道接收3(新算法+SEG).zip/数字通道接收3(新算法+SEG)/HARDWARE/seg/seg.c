#include "seg.h"
unsigned char  dula[] = 
{// 0	 1	  2	   3	4	 5	  6	   7	8	 9	  A	   b	C    d	  E    F    -
	0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x8C,0xBF,0xC6,0xA1,0x86,0xFF,0xbf
};
uint8_t LED[8]={0xC0,0xF9,0xA4,0xB0,0xff,0xff,0xff,0xff};
uint8_t i=0,pos=0x01,j=0;

void Seg_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;            //����IO�ڳ�ʼ�����ݵĽṹ��
	
	RCC_APB2PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE); // IO��ʱ��ʹ��
	
	GPIO_InitStructure.GPIO_Pin = SCLK_PIN | RCLK_PIN | DIO_PIN ;  //��ʼ������IO��
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;        //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;	//�ٶ�25MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;      //���츴�����
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;        //����
	GPIO_Init(SCLK_GPIO_Port, &GPIO_InitStructure);             //��ʼ��GPIOC
	//GPIO_SetBits(SCLK_GPIO_Port, GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6);
}

void LED4_Display (void)
{
	unsigned char  led_table;          // ���ָ��
	//��ʾ��1λ
	led_table = LED[j];
	i = led_table;

	LED_OUT(i);			
	LED_OUT(pos);	
 
    
	RCLK(0);
	RCLK(1);
    pos=(pos<<1);
    if(pos==0x10)pos=0x01;
    if(++j>3)j=0;
	

//	RCLK(0);
//	RCLK(1);
//	//��ʾ��2λ
//	led_table = LED[1];
//	i = led_table;

//	LED_OUT(i);		
//	LED_OUT(0x02);		

//	RCLK(0);
//	RCLK(1);
//	//��ʾ��3λ
//	led_table = LED[2];
//	i = led_table;

//	LED_OUT(i);			
//	LED_OUT(0x04);	

//	RCLK(0);
//	RCLK(1);
//	//��ʾ��4λ
//	led_table = LED[3];
//	i = led_table;
// 
//	LED_OUT(i);			
//	LED_OUT(0x08);		

//	RCLK(0);
//	RCLK(1);
}

void LED_OUT(uint8_t X)
{
	uint8_t i;
	for(i=8;i>=1;i--)
	{
		if (X&0x80) DIO(1); else DIO(0);
		X<<=1;
		SCLK(0);
		SCLK(1);
	}
}

