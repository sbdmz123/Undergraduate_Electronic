#ifndef __SEG_H__
#define __SEG_H__
#include "sys.h"
#define SCLK_GPIO_Port     GPIOA
#define RCLK_GPIO_Port     GPIOA
#define DIO_GPIO_Port      GPIOA
#define SCLK_PIN           GPIO_Pin_0
#define RCLK_PIN		   GPIO_Pin_1
#define DIO_PIN		       GPIO_Pin_2
#define SCLK(n)  (n?GPIO_SetBits(SCLK_GPIO_Port, SCLK_PIN):GPIO_ResetBits(SCLK_GPIO_Port, SCLK_PIN))
#define RCLK(n)  (n?GPIO_SetBits(RCLK_GPIO_Port, RCLK_PIN):GPIO_ResetBits(RCLK_GPIO_Port, RCLK_PIN))
#define DIO(n)   (n?GPIO_SetBits(DIO_GPIO_Port, DIO_PIN):GPIO_ResetBits(DIO_GPIO_Port, DIO_PIN))

extern unsigned char  dula[];
extern uint8_t LED[];

void Seg_Init(void);
void LED4_Display (void);
void LED_OUT(uint8_t X);

#endif/*__SEG_H__*/
