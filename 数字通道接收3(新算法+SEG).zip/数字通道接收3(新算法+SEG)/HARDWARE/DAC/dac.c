#include "dac.h"

u16 dac_val[2][1024]={3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,
3000,3000,3000,3000,3000,3000,3000,3000,3000,3000,};

void DAC_DMA_Init(void)
{
	DMA_InitTypeDef  DMA_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1,ENABLE);                          //DMA1ʱ��ʹ��
	
	DMA_DeInit(DMA1_Stream5);
	
	while (DMA_GetCmdStatus(DMA1_Stream5) != DISABLE){}                             //�ȴ�DMA������ 
		
	/* ���� DMA Stream */
	DMA_InitStructure.DMA_Channel = DMA_Channel_7;                                 //ͨ��ѡ��
	DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)DAC_DHR12R1;                   //DMA�����ַ
	DMA_InitStructure.DMA_Memory0BaseAddr = (u32)dac_val[0];                       //DMA �洢��0��ַ
	DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;                        //�洢��������ģʽ
	DMA_InitStructure.DMA_BufferSize = 1024;                                       //���ݴ����� 
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;               //���������ģʽ
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;                        //�洢������ģʽ
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;    //�������ݳ���:16λ
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;            //�洢�����ݳ���:16λ
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;                                //ʹ������ģʽ 
	DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;                          //�е����ȼ�
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;         
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;                    //�洢��ͻ�����δ���
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;            //����ͻ�����δ���
	DMA_Init(DMA1_Stream5, &DMA_InitStructure);                                     //��ʼ��DMA Stream
	DMA_ClearFlag(DMA1_Stream5,DMA_IT_TC);
	DMA_ITConfig(DMA1_Stream5,DMA_IT_TC,ENABLE);
		
	DMA_DoubleBufferModeConfig(DMA1_Stream5,(u32)dac_val[1],DMA_Memory_0);//˫����ģʽ����

	DMA_DoubleBufferModeCmd(DMA1_Stream5,ENABLE);//˫����ģʽ����
	
	NVIC_InitStructure.NVIC_IRQChannel=DMA1_Stream5_IRQn; 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x01;                     //��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x01;                            //��Ӧ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	while (DMA_GetCmdStatus(DMA1_Stream5) != DISABLE){}
	DMA_Cmd(DMA1_Stream5, ENABLE); //����DMA
}

void Dac_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	DAC_InitTypeDef DAC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);//???DAC???
	  
	//DAC_DMA_Init();
	
	/*ʹ��PA4*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 ;//DAC_OUT_1
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;//ģ������
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;//����
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	//DAC_I4����ת��
	DAC_InitStructure.DAC_Trigger = DAC_Trigger_None;
	DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
	DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
	DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude=DAC_LFSRUnmask_Bit0;
	DAC_Init(DAC_Channel_1, &DAC_InitStructure);
	
	//DAC_DMACmd(DAC_Channel_1, ENABLE);
	DAC_Cmd(DAC_Channel_1, ENABLE);
}